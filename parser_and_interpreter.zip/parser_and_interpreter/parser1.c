#include<stdio.h>
#include<stdlib.h>
//#include "lex1.h"
//#include "lex1.c"
#include "parser1.h"
int parser(ASTnode_t *ap)
{
  ASTnode_t *u,*v;
  while(1)
  {
    getNextToken();
    //printf("%d\n",token.tokenclass);
    if(token.tokenclass==-1)
    {
        break;
        return 0;
    }
    else if(token.tokenclass==1)
    {
      u=(ASTnode_t *)malloc(sizeof(ASTnode_t));
     // u->type=NULL;
      u->left=NULL;
      u->right=NULL;
      ap->left=u;
      parser(u);
    }
    else if(token.tokenclass==2)
    {
       return 1;
    }
    else if(token.tokenclass==3 || token.tokenclass==4)
    {
      ap->type='s';
      if(token.tokenclass==3)
      {
          ap->op='+';
      }
      else
      {
         ap->op='*';
      }
      v=(ASTnode_t *)malloc(sizeof(ASTnode_t));
      v->left=NULL;
      v->right=NULL;
      ap->right=v;
      parser(v);
    }
    else if(token.tokenclass==6)
    {
      ap->type='n';
      ap->val=token.val;
      return 0;
    }
    else if(token.tokenclass==7)
    {
        ap->type='d';
        ap->op='r';
        return 0;
    }
   // return 0;
}
return 0;
}
/*struct tree* create_tree(struct tree *ap)
{
  struct tree *u,*v;
  while(1)
  {
    char a=get_token();
    if(a==EOF)
    {
      break;
    }
    else if(a=='(')
    {
      u=(struct tree*)malloc(sizeof(struct tree));
      u->left=NULL;
      u->right=NULL;
      ap->left=u;
      create_tree(u);
    }
    else if(a==')')
    {
       return ap;
    }
    else if(a=='+' || a=='*')
    {
      ap->val=a;
      v=(struct tree*)malloc(sizeof(struct tree));
      v->left=NULL;
      v->right=NULL;
      ap->right=v;
      create_tree(v);
    }
    else
    {
      ap->val=a;
      return ap;
    }
}
return ap;
}*/
