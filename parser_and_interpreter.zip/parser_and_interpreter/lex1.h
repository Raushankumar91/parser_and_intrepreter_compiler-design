#ifndef LEX_H
#define LEX_H

#include <stdio.h>
#define END 256
#define NUM 257
typedef struct
 { int tokenclass; 
int val; }token_t;
extern token_t token;
extern void getNextToken(void);
#endif
