#include "backend1.h"
int preorder(ASTnode_t *p,int v)
{
   if(p->type=='n')
   {
      return p->val;
   }
   else if(p->type=='d')
   {
       return v;
   }
   else
   {
         int k1,k2;
         k1=preorder(p->left,v);
         k2=preorder(p->right,v);
         if(p->op=='+')
         {
            return k1+k2;
         }
         else
         {
            return k1*k2;
         }
  }
}
