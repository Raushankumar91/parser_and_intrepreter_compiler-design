#include<stdio.h>
#include<stdlib.h>
#include "lex1.h"
token_t token;
int IS_NUM(char p)
{
   if(p>=48 && p<=57)
   {
       return 1;
   }
   else
   {
        return 0;
   }
}
void getNextToken()
{
   char a,b;
   int num;
   scanf("%c",&a);
   if(a=='(')
   {
       token.tokenclass=1;
       token.val=-1;
   }
   else if(a==')')
   {
       token.tokenclass=2;
       token.val=-1;
   }
   else if(a=='+')
   {
       token.tokenclass=3;
       token.val=-1;
   }
   else if(a=='*')
   {
       token.tokenclass=4;
       token.val=-1;
   }
   else if(a>=48 && a<=57)
   {
        num=a-'0';
        while(scanf("%c",&a)!=EOF && IS_NUM(a))
        {
            num=num*10+(a-'0');
        }
        ungetc(a,stdin);
        token.tokenclass=6;
        token.val=num;
  }
  else if(a=='r')
  {
      token.tokenclass=7;
      token.val=-1;
 }
  else if(a==' ' || a=='\n')
  {
        return;
  }
  else if(a==EOF)
  {
      token.tokenclass=-1; 
}
}
