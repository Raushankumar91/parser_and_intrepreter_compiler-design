#include "lex1.h"
#include "parser1.h"
#include"lex1.c"
#include "backend1.h"
#include "backend1.c"
#include "parser1.c"
#include<stdio.h>
#include<stdlib.h>
int main()
{
    int k,r,sa;
    printf("Enter the expression\n");
    ASTnode_t* astTree = (ASTnode_t*)malloc(sizeof(ASTnode_t));
    k=parser(astTree);
    if(k)
    {
        printf("Tree  created succesfully\n:");
        printf("Enter value of r is given \n");
        scanf("%d",&r);
        sa=preorder(astTree,r);
        printf("%d\n",sa);
    }
    else
    {
        printf("Tree not created succesfully\n");
     }
}
